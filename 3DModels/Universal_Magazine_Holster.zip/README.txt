                   .:                     :,                                          
,:::::::: ::`      :::                   :::                                          
,:::::::: ::`      :::                   :::                                          
.,,:::,,, ::`.:,   ... .. .:,     .:. ..`... ..`   ..   .:,    .. ::  .::,     .:,`   
   ,::    :::::::  ::, :::::::  `:::::::.,:: :::  ::: .::::::  ::::: ::::::  .::::::  
   ,::    :::::::: ::, :::::::: ::::::::.,:: :::  ::: :::,:::, ::::: ::::::, :::::::: 
   ,::    :::  ::: ::, :::  :::`::.  :::.,::  ::,`::`:::   ::: :::  `::,`   :::   ::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  :::::: ::::::::: ::`   :::::: ::::::::: 
   ,::    ::.  ::: ::, ::`  :::.::    ::.,::  .::::: ::::::::: ::`    ::::::::::::::: 
   ,::    ::.  ::: ::, ::`  ::: ::: `:::.,::   ::::  :::`  ,,, ::`  .::  :::.::.  ,,, 
   ,::    ::.  ::: ::, ::`  ::: ::::::::.,::   ::::   :::::::` ::`   ::::::: :::::::. 
   ,::    ::.  ::: ::, ::`  :::  :::::::`,::    ::.    :::::`  ::`   ::::::   :::::.  
                                ::,  ,::                               ``             
                                ::::::::                                              
                                 ::::::                                               
                                  `,,`


http://www.thingiverse.com/thing:977519
Universal Magazine Holster by IVIUPPET is licensed under the Creative Commons - Attribution - Non-Commercial license.
http://creativecommons.org/licenses/by-nc/3.0/

# Summary

Introducing the (almost) completely 3D printable Universal Magazine Holster!  Also known as a hard magazine pouch, this Thing provides a way to securely store your pistol magazine while also allowing for quick access.  
____  
Edit 9/20/15: I regret to inform you all that I had to remove this Thing from my loadout at the 10th annual combat rifle championship last weekend.  While more action packed than most activities, this 3D printed mag pouch just isn't as strong as my injection molded one (thin wall ABS never seems to work well for me) and I observed a crack down the sides forming.  I removed it because dropping a loaded mag is a penalty, though it is still usable for casual range days.  I ended up winning some cool stuff though, I'll try and modify this to make it better when I get time.  
____  
Edit 8/29/15: It should be noted that single stack magazine retention has not been perfected.  But, thanks to modular design, the retention strap is the only thing that will need to be reprinted.  
____
I have seen other designs with retention, but they require a specific make/model of magazine and use the accuracy of the 3D printer (which can vary significantly especially across the entire Thingiverse!) to provide a snug fit on only one type of magazine.  

This design uses a separate and custom retention strap to secure any magazine (double stack fits better) so it shouldn't fall out while crawling through a tunnel, pursuing a hostile, or doing any other intense physical activity (though I strongly recommend purchasing a commercial variant that is injection molded if your life depends on this).  
I have included renders for viewing pleasure, followed by instructional pictures for installation,  application..... and just some pictures of guns :D  

See instructions tab for instructions.  
_____  
On an end note I'd like to issue a public service announcement. Some readers may notice the prominently placed "No Excuse for Sexual Assault" cup surrounded by guns.  This is in response to my recent (third) encounter with ANOTHER person who was molested as a young girl.  She was also raped later on in life and we live in a society that seems to just brush this issue under the rug.  ~3/4 of the women I have dated have been raped or have had a very close call and this is a startling statistic.  She is very smart, and caring, and is also a Thingiverse user.  Unfortunately she contemplates suicide because of her scars on top of being bullied at school because of her lovely nerdy nature (aren't all Thingiverse users? :P ).  
As much as I'd love to think all rapists could be blown away by guns, unfortunately most rapes are committed by someone you know or under situations where it would be inappropriate to be carrying (i.e. at a party or bar with alcohol) in which case the best tool is vigilance.  If you see something, say something.  This underreported crime destroys lives, and leaves their victims desperate and suicidal, often with nightmares every night following.  In my opinion this is worse than death, and unfortunately the victims often feel this way.  For the less frequent occurrences of "stranger rape", like the poor soul jogging at 5AM at my university recently (edit: typo, a street nearby called 'north lawn' not the north lawn of the university), if you are the victim currently undergoing the assault you are well within your right to blast that bastard straight to hell (and please do, it does us all a favor).  Unfortunately, it seems to me like it's the best shot at justice you'll have since we have courts and jury pools that believe this crime doesn't exist.  I am still a strong advocate for self defense, and there's nothing that reliably levels the playing field in a fight like a gun.  

Be sure to use quality hollow point ammunition such as the Winchester Ranger ammo pictured next to my Sig p938 in the demo of magazine fitting to avoid overpenatration and potential bystander injury.

# Instructions

Print as oriented in Makerware screenshot, though not all at the same time to facilitate more even layer cooling and better chances of success.  coolarj10 has reported that the UniMag_Body1.1.stl can be printed vertically, though I am still testing this. My concern is the clip to hold the belt clip on will break over time putting that much stress on the layers, but maybe it doesn't bend enough.

The pictures are ordered to show beginning presenation/rendering, print orientation, assembly, modification (if necessary), and finally various magazines and their fit.  

UniMag_Body1.1.stl should be printed with 100% infill, 1 shell, your choice of layer height (I used 0.2mm for all parts), and RAFT and SUPPORTS (unfortunately -- I did my best to avoid needing them).  

UniMag_Clip1.1.stl   
and  
UniMag_Ret.stl  
Should also be printed with 100% infill, 1 shell, and with raft and supports.  See Makerware screenshot for recommended orientation.  

I strongly recommend using ABS or some other thermoplastic with give due to the flexibility requirements of these parts.  

Once all the parts are printed and support material removed -- I recommend a needle nose pliers -- use two #4x1/2" screws to attach the retention strap as shown in the renderings. For you lucky metric users, this comes out to a ~2.794x12.7mm wood screw.  I prefer metric but there were imperial unit screws at the store. Thingiverse user coolarj10 reports that M3x10 screws will work, but I don't have access to these screws to test unfortunately. If your ABS part came out slightly warped like mine, some sanding in the areas indicated by the red arrows in the later pictures might be necessary.  

The last step is to slide the belt clip into the body, shown in the renderings.  

I have used my "replacement parts" clip:  
http://www.thingiverse.com/thing:963780  
in a commercial hard magazine pouch in a few action matches and it hasn't broken yet.  I haven't noticed any stress marks on the body or the retention strap, though, so I think they have been successfully tweaked to last a long time (the first version of the body did exhibit stress marks when installing/removing belt clip).  Please let me know if you encounter any issues.  Have fun, stay safe, and happy shooting! (and 3D printing!)